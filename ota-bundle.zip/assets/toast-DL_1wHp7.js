function o(t){typeof window<"u"&&window.dispatchEvent(new CustomEvent("show-app-toast",{detail:t}))}export{o as s};
